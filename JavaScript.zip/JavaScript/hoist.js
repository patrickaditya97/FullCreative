console.log(val1)
var val1 = 122;
console.log(val1)

console.log(val2)
let val2 = 122;
console.log(val2)

console.log(val3)
var val3 = 122;
console.log(val3)
