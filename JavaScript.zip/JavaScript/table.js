// (function()
// {
//     console.log("started function");
//     console.log(remove_elem)

    // var remove_elem  = document.getElementsByClassName('btn_rm');

    // for (var i = 0; i < remove_elem.length; i++) {
    //     remove_elem[i].addEventListener('click', function()
    //     {
    //         console.log("id:", event.target.id);
    //         console.log("click");
    //         console.log(this)
    //         this.closest("tr").remove();
    //     })
    // }





    let add_elem  = document.getElementById('btn_add');
    var click = 0;

    
    add_elem.addEventListener('click', function_add, false)

    function function_add()
    {
        // alert()

        var table_elem = document.getElementById('dyn_tr')
        var tr_elem = document.createElement('tr')
        var click_count = ++click;
        tr_elem.innerHTML = '<tr id="dyn_td"><td>132</td>' +
                    '<td>Patrick</td>' +
                    '<td>9176424449</td>' +
                    '<td>mpatrick97@gmail.com</td>' +
                    '<td><button type="button" name="button" id="btn'+ click_count +'" onclick="removes(this)">Delete</button></td></tr>';

        console.log(tr_elem) 
        
        table_elem.appendChild(tr_elem)
        
    }
    
function removes(e)
{
    e.target.closest("tr").remove();
    // var removebutton = document.querySelectorAll(".btn_rm");
    // var tr = document.querySelectorAll('#dyn_td');

    // for(let i=0; i<removebutton.length; i++)
    // {
    //     removebutton[i].addEventListener('click', function(e)
    //     {
    //         // console.log(removebutton[i])
    //         this.closest("tr").remove();
    //     })
    // }
    // for(let i=0;i<removebutton.length;i++){
    //     removebutton[i].addEventListener('click',function(e){
    //         tr[i].style.display = "none";
    //     })
    // }

    
}
    

// })()